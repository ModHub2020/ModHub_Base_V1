#pragma once

namespace Features {

	void UpdateLoop();

	//extern bool examplebool;
//	void example(bool toggle);

	extern bool Godmode;
	void godmode(bool toggle);

	extern bool Ghostmode;
	void ghostmode(bool toggle);

	extern bool Superjump;
	void superjump(bool toggle);

	extern bool Neverwanted;
	void neverwanted(bool toggle);

	extern bool rainbowmenu;
	void Rainbowmenu(bool toggle);
}



